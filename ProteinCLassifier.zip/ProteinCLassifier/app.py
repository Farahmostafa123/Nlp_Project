from flask import Flask, request, jsonify
import torch
import torch.nn as nn
import numpy as np
import pickle

class ProteinBiLSTMClassifier(nn.Module):
    def __init__(self, vocab_size, embed_dim=128, hidden_dim=256, num_classes=20):
        super().__init__()
        self.embedding = nn.Embedding(vocab_size, embed_dim, padding_idx=0)
        self.bilstm = nn.LSTM(embed_dim, hidden_dim, batch_first=True, bidirectional=True)
        self.batchnorm = nn.BatchNorm1d(hidden_dim * 2)
        self.dropout = nn.Dropout(0.3)
        self.fc1 = nn.Linear(hidden_dim * 2, hidden_dim)
        self.relu = nn.ReLU()
        self.fc2 = nn.Linear(hidden_dim, num_classes)

    def forward(self, x):
        x = self.embedding(x)
        _, (hidden, _) = self.bilstm(x)
        hidden = torch.cat((hidden[-2], hidden[-1]), dim=1)
        hidden = self.batchnorm(hidden)
        x = self.dropout(hidden)
        x = self.relu(self.fc1(x))
        return self.fc2(x)

amino_acids = list('ACDEFGHIKLMNPQRSTVWY')
aa_to_int = {aa: i + 1 for i, aa in enumerate(amino_acids)}
max_seq_len = 350
vocab_size = len(aa_to_int) + 1

with open("label_encoder.pkl", "rb") as f:
    le = pickle.load(f)

model = ProteinBiLSTMClassifier(vocab_size=vocab_size, num_classes=len(le.classes_))
model.load_state_dict(torch.load("protein_classifier.pt", map_location=torch.device("cpu")))
model.eval()

app = Flask(__name__)

@app.route("/predict", methods=["POST"])
def predict():
    data = request.get_json()
    sequence = data.get("sequence", "").strip().upper()

    if not sequence or any(char not in aa_to_int for char in sequence):
        return jsonify({"error": "Invalid or empty sequence"}), 400

    encoded = [aa_to_int.get(aa, 0) for aa in sequence]
    padded = torch.tensor([encoded[:max_seq_len] + [0]*(max(0, max_seq_len - len(encoded)))], dtype=torch.long)

    with torch.no_grad():
        logits = model(padded)
        pred = logits.argmax(1).item()
        class_name = le.inverse_transform([pred])[0]

    harmful_keywords = ['viral', 'toxin', 'immune', 'harmful', 'unknown']
    is_harmful = any(keyword in class_name.lower() for keyword in harmful_keywords)

    return jsonify({
        "predicted_class": class_name,
        "harmful": is_harmful
    })

if __name__ == "__main__":
    app.run(debug=True)
